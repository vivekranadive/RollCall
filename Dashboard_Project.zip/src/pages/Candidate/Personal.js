import React from "react";
import SubTabs from "../../components/SubTabs";
import { Route, Routes } from "react-router-dom";

const Personal = () => {
  return (
    <div>
      {/* <SubTabs /> */}
      
    </div>
  );
};

export default Personal;
