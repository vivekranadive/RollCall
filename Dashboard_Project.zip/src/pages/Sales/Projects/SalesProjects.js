import React, { useEffect, useState } from "react";
import Modal from "../../../components/ModalComponents/Modal";
import StarRating from "../../../components/StarRating";
import { RxReload } from "react-icons/rx";
import QrCode from "../../../images/Qr-code.png";
import { toast } from "react-toastify";
import { getUserInfoDetails } from "../../../utlis";
import Loader from "../../../components/Loader";
import Pagination from "../../../components/Pagination";
import { useForm } from "react-hook-form";
import axiosInstance from "../../../api/axiosInstance";
const { companyId, clientId } = getUserInfoDetails()

const SalesProjects = () => {
  const { register, handleSubmit, reset,watch, formState: { errors } } = useForm({
    defaultValues: {
      projectStatus: "active",
    },
  });
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLoading, setLoading] = useState(false)
  const [data, setData] = useState([])
  const [pageSize, setPageSize] = useState(10);

  const projectStatus = watch("projectStatus");

  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  const getData = async (page = 1) => {
    setLoading(true)
    try {
      const res = await axiosInstance.get('/projects', {
        params: { company: companyId, client: clientId }
      });
      console.log(res.data.response.data);
      setData(res.data.response.data)
    } catch (err) {
      toast.error('Something Went Wrong')
      console.log(err);
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    getData()
  }, [])




  const columns = [
    {
      name: "first_name", 
      label: "Project Info",
      options: {
        customBodyRender: (value, tableMeta, updateValue) => {
          const firstName = tableMeta.rowData[tableMeta.columnIndex];
          const lastName = tableMeta.rowData[tableMeta.columnIndex + 1]; // Adjust index if necessary
          const fullName = lastName ? `${firstName} ${lastName}` : firstName;
          return (
            
            <h3 className="text-base font-bold text-auxiliary-800 cursor-pointer">
              {`${fullName}`}
            </h3>
          );
        }
      }
    },
    {
      name: "job_title",
      label: "Candidate",
    },
    {
      name: "mobile",
      label: "Vendor",
    },
    {
      name: "email",
      label: "Client",
    },
    {
      name: "address",
      label: "City",
    },
    {
      name: "address",
      label: "Start Date",
    },
    {
      name: "address",
      label: "End Date",
    },
    {
      name: "address",
      label: "Created on",
    },
    {
      name: "address",
      label: "Duration",
    },
    {
      name: "status",
      label: "Project Status",
      options: {
        customBodyRender: (value) => {
          return (
            <p 
              className={`border py-2 px-6 rounded-full w-32 text-center ${
                value === 'active' 
                  ? 'border-secondary-500 text-secondary-500' 
                  : 'border-danger-500 text-danger-500'
              }`}
            >
              {value}
            </p>
          );
        },
      },
    },
    
  ];
  const options = {
    filterType: 'dropdown',
    responsive: 'standard',
    rowsPerPage: pageSize,
    rowsPerPageOptions: [5, 10, 20, 50, 100, 200],
    onChangeRowsPerPage: (numberOfRows) => setPageSize(numberOfRows),
    selectableRows: false,
    elevation: 0,
    onRowClick: (rowData, rowMeta) => {
    prepareUpdate(rowData);
    },
  };
  return (
    <div className="p-5 ">
      {isLoading && <Loader />}
      <Modal isOpen={isModalOpen} onClose={closeModal}>
        <div className="">
          <form className="flex flex-col gap-6">
            <div className="grid grid-cols-3 gap-5">
              <div className="flex flex-col w-72">
                <label htmlFor="project_tiel" className="text-text-hint mb-1">
                  Project Title
                </label>
                <input
                  type="text"
                  placeholder="Project Title"
                  id="project_tiel"
                  className="outline-none border-2 border-secondary-500 rounded-lg "
                />
              </div>
              <div className="flex flex-col w-72">
                <label htmlFor="project" className="text-text-hint mb-1">
                  Project
                </label>
                <input
                  type="text"
                  placeholder="Project"
                  id="project"
                  className="outline-none border-2 border-secondary-500 rounded-lg "
                />
              </div>
              <div className="flex flex-col w-72">
                <label htmlFor="client" className="text-text-hint mb-1">
                  Client
                </label>
                <input
                  type="text"
                  placeholder="Client"
                  id="client"
                  className="outline-none border-2 border-secondary-500 rounded-lg "
                />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-5">
              <div className="flex flex-col w-72">
                <label htmlFor="vendor" className="text-text-hint mb-1">
                  Vendor
                </label>
                <input
                  type="text"
                  placeholder="Vedor "
                  id="vendor"
                  className="outline-none border-2 border-secondary-500 rounded-lg "
                />
              </div>
              <div className="flex flex-col w-72">
                <label htmlFor="cnadidate_name" className="text-text-hint mb-1">
                  Candidate Name
                </label>
                <input
                  type="text"
                  placeholder="Candidate Name "
                  id="cnadidate_name"
                  className="outline-none border-2 border-secondary-500 rounded-lg "
                />
              </div>
              <div className="flex flex-col w-72">
                <label htmlFor="sales_manager" className="text-text-hint mb-1">
                  Sales Manager
                </label>
                <input
                  type="text"
                  placeholder="Sales Manager "
                  id="sales_manager"
                  className="outline-none border-2 border-secondary-500 rounded-lg "
                />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-5">
              <div className="flex flex-col w-72">
                <label htmlFor="hr_contact" className="text-text-hint mb-1">
                  HR Contact
                </label>
                <input
                  type="text"
                  placeholder="HR Contact"
                  id="hr_contact"
                  className="outline-none border-2 border-secondary-500 rounded-lg "
                />
              </div>
              <div className="flex flex-col w-72">
                <label htmlFor="vendor_contact" className="text-text-hint mb-1">
                  Vendor Contact
                </label>
                <input
                  type="text"
                  placeholder="Vendor Contact"
                  id="vendor_contact"
                  className="outline-none border-2 border-secondary-500 rounded-lg "
                />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-5">
              <div className="flex flex-col w-72">
                <label htmlFor="bill_rate" className="text-text-hint mb-1">
                  Bill Rate
                </label>
                <input
                  type="text"
                  placeholder="Bill Rate"
                  id="bill_rate"
                  className="outline-none border-2 border-secondary-500 rounded-lg "
                />
              </div>
              <div className="flex flex-col w-72">
                <label htmlFor="pay_type" className="text-text-hint mb-1">
                  Pay Type
                </label>
                <input
                  type="text"
                  placeholder="Pay Type"
                  id="pay_type"
                  className="outline-none border-2 border-secondary-500 rounded-lg "
                />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-6">
              <div className="flex flex-col w-72">
                <label
                  htmlFor="marketing_start_date"
                  className="text-text-hint mb-1"
                >
                  Marketing Start Date
                </label>
                <input
                  type="date"
                  id="marketing_start_date"
                  className="outline-none border-2 border-text-hint rounded-lg "
                />
              </div>
              <div className="flex flex-col w-72">
                <label
                  htmlFor="marketing_end_date"
                  className="text-text-hint mb-1"
                >
                  Marketing End Date
                </label>
                <input
                  type="date"
                  id="marketing_end_date"
                  className="outline-none border-2 border-text-hint rounded-lg "
                />
              </div>
              <div className="flex flex-col w-72">
                <label htmlFor="duration" className="text-text-hint mb-1">
                  Duration
                </label>
                <select className="flex justify-center items-center focus:ring-0 px-3 py-2  border border-neutral-500 rounded-lg outline-none w-full">
                  <option>1</option>
                  <option>2</option>
                  <option>3</option>
                  <option>4</option>
                  <option>5</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-5">
              <div className="flex flex-col w-72">
                <label htmlFor="State" className="text-text-hint mb-1">
                  State
                </label>
                <select className="flex justify-center items-center focus:ring-0 px-3 py-2  border border-neutral-500 rounded-lg outline-none w-full">
                  <option>1</option>
                  <option>2</option>
                  <option>3</option>
                  <option>4</option>
                  <option>5</option>
                </select>
              </div>
              <div className="flex flex-col w-72">
                <label htmlFor="city" className="text-text-hint mb-1">
                  City
                </label>
                <select className="flex justify-center items-center focus:ring-0 px-3 py-2  border border-neutral-500 rounded-lg outline-none w-full">
                  <option>1</option>
                  <option>2</option>
                  <option>3</option>
                  <option>4</option>
                  <option>5</option>
                </select>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-6">
              <div className="flex flex-col w-72">
                <label htmlFor="start_date" className="text-text-hint mb-1">
                  Start Date
                </label>
                <input
                  type="date"
                  id="start_date"
                  className="outline-none border-2 border-text-hint rounded-lg "
                />
              </div>
              <div className="flex flex-col w-72">
                <label
                  htmlFor="marketing_end_date"
                  className="text-text-hint mb-1"
                >
                  End Date
                </label>
                <input
                  type="date"
                  id="end_date"
                  className="outline-none border-2 border-text-hint rounded-lg "
                />
              </div>
            </div>

            <div className="">
              <div className="w-96">
                <label className="text-text-hint ">Project Status</label>
                <ul className="grid grid-cols-3 mt-1">
                  <li className="relative">
                    <input
                      className="sr-only peer"
                      type="radio"
                      value="InPrgress"
                      name="interview_status"
                      id="in_progress"
                    />
                    <label
                      className="flex justify-center items-center py-2 px-3 text-sm text-text-hint bg-white border border-secondary-800 rounded-tl-full rounded-bl-full cursor-pointer focus:outline-none hover:bg-gray-50 peer-checked:bg-secondary-500 peer-checked:text-white peer-checked:border-secondary-800"
                      htmlFor="in_progress"
                    >
                      InPrgress
                    </label>
                  </li>
                  <li className="relative">
                    <input
                      className="sr-only peer"
                      type="radio"
                      value="ShortListed"
                      name="interview_status"
                      id="shortlisted"
                    />
                    <label
                      className="flex justify-center items-center py-2 px-3 text-sm text-text-hint bg-white border border-t-secondary-800 border-b-secondary-800 cursor-pointer focus:outline-none hover:bg-gray-50 peer-checked:bg-secondary-500 peer-checked:text-white peer-checked:border-secondary-800"
                      htmlFor="shortlisted"
                    >
                      ShortListed
                    </label>
                  </li>

                  <li className="relative">
                    <input
                      className="sr-only peer"
                      type="radio"
                      value="Not Selected"
                      name="interview_status"
                      id="not_selected"
                    />
                    <label
                      className="flex justify-center items-center py-2 px-3 text-sm text-text-hint bg-white border border-secondary-800 rounded-tr-full rounded-br-full cursor-pointer focus:outline-none hover:bg-gray-50 peer-checked:bg-secondary-500 peer-checked:text-white peer-checked:border-secondary-800"
                      htmlFor="not_selected"
                    >
                      Not Selected
                    </label>
                  </li>
                </ul>
              </div>
            </div>
          </form>
          <div className="flex justify-between p-6 mt-6">
            <button
              onClick={closeModal}
              className="border border-secondary-800 text-secondary-800 py-2 px-5 rounded-full"
            >
              Close
            </button>
            <button
              onClick={closeModal}
              className="bg-secondary-700 text-text-light py-2 px-5 rounded-full"
            >
              Save
            </button>
          </div>
        </div>
      </Modal>
      <div className="border border-gray-300 rounded-lg ">
        <div className="flex justify-between items-center gap-2 p-3">
          <RxReload size={20} />

          <button
            onClick={openModal}
            className="py-3 px-6 bg-secondary-700 text-white rounded-full"
          >
            <span className="mr-3">+</span>
            Add New Project
          </button>
        </div>
        <div className="w-full overflow-x">
          <table class="table-auto overflow-scroll w-full">
            {/* Table headings */}
            <thead className="w-full">
              <tr className="grid grid-cols-10  text-left py-3 pl-3 pr-6 bg-secondary-50 text-sm">
                <th>Project Info</th>
                <th>Candidate</th>
                <th>Vendor</th>
                <th>Client</th>
                <th>City</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Created on</th>
                <th>Duration</th>
                <th>Project Status</th>
              </tr>
            </thead>
            {/* table content/data */}
            <tbody
              className="flex flex-col items-center  overflow-y-scroll w-full h-screen"
            // style={{ height: "90vh" }}
            >
              {data.map((d) => (
                <tr className="grid grid-cols-10 justify-center items-center py-2 px-3 gap-1 border border-gray-200 text-left w-full text-sm">
                  <td className="">
                    <button onClick={openModal}>
                      <h3 className="text-base font-bold text-auxiliary-800">
                        Sales Tech
                      </h3>
                    </button>
                    <p className="text-text-hint">salesforce</p>
                  </td>
                  <td className="">Bessie </td>
                  <td className="">Technology</td>
                  <td className="">Technology</td>
                  <td className="">DuR</td>
                  <td className="">10/10/2023</td>
                  <td className="">10/10/2023</td>
                  <td className="">10/10/2023</td>
                  <td className="">12 months</td>
                  <td className="flex">
                    <p className="py-2 px-4 text-danger-700 border border-danger-700 rounded-full text-xs">
                      Not Selected
                    </p>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

      </div>
    </div>
  );
};

export default SalesProjects;
