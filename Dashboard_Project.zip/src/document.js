/**
 *  /sales/contacts  -> Page
 *  
 *  This Page have the New Contact button to add new Contact, You click on this a form would open
 *  Now its have the Notes field, According to the brief that was provided in the document. We need to hit the notes
 *  Api fiest with the param recordType = contact and then pass it to the main load, But now we are getting error in this
 *  because we are getting the error from API as the API expecting candidateId but we don't have it here.
 *
 */

/**
 * /sales/vendors/new-vendor/summary/account-info
 * 
 * This path contain the form which have the Account Type field as per the document it says we would get the value form the config object
 * But we don't have so 
 * 
 */